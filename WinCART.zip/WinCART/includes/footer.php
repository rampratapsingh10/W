<footer>
    <div class="container">
        <center>
          <p>wincart@gmail.com</p>
	  
          <p> Copyright &copy; Contact Us at tollfree: 1800310030</p>	
        </center>
    </div>
</footer>